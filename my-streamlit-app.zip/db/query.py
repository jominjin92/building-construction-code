from db.connection import get_connection
import pandas as pd
import os
import csv
from datetime import datetime

def record_feedback(user_id, problem_id, feedback_text):
    with get_connection() as conn:
        cursor = conn.cursor()
        cursor.execute("""
            INSERT INTO feedback (user_id, problem_id, feedback_text)
            VALUES (?, ?, ?)
        """, (user_id, problem_id, feedback_text))
        conn.commit()

def get_all_feedback():
    with get_connection() as conn:
        return pd.read_sql_query("SELECT * FROM feedback ORDER BY feedback_time DESC", conn)

def record_attempt(user_id, problem_id, user_answer, is_correct):
    with get_connection() as conn:
        cursor = conn.cursor()
        cursor.execute("""
            INSERT INTO attempts (user_id, problem_id, user_answer, is_correct)
            VALUES (?, ?, ?, ?)
        """, (user_id, problem_id, user_answer, is_correct))
        conn.commit()

def save_result_to_csv(user_id, question, selected, correct, concept, is_correct, solve_time):
    file_path = "data/results.csv"
    os.makedirs(os.path.dirname(file_path), exist_ok=True)  # ✅ 폴더 없으면 자동 생성

    file_exists = os.path.exists(file_path)
    with open(file_path, mode="a", newline="", encoding="utf-8-sig") as file:
        writer = csv.writer(file)
        if not file_exists:
            writer.writerow(["사용자ID", "문제", "선택한답", "정답", "정오답", "풀이날짜", "개념", "풀이시간"])
        writer.writerow([
            user_id,
            question,
            selected,
            correct,
            "정답" if is_correct else "오답",
            datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            concept,
            solve_time
        ])